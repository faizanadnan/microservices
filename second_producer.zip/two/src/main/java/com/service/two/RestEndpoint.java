package com.service.two;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.ws.rs.core.MediaType;

@RestController
public class RestEndpoint {

    Logger logger = LoggerFactory.getLogger(RestEndpoint.class);

    @RequestMapping(path ="/username" ,consumes = MediaType.APPLICATION_XML, method = RequestMethod.POST)
    public String getUserName(@RequestBody User user) {
        logger.debug("In get User method");
        if(!isValidJson(user)) {
            logger.debug("failing with wrong payload exception");
            throw new IllegalArgumentException();
        }
        return user.getFirstName() + " " + user.getSecondName();

    }

    private boolean isValidJson(User user) {
        return !(user == null ||
                user.getFirstName().isEmpty() ||
                user.getSecondName().isEmpty());
    }
}
