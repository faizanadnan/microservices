package com.service.one.main.service;

import com.service.one.main.model.GenericModel;

import java.util.List;

public interface GenericService {
    List<GenericModel> getGenericModel();
}
