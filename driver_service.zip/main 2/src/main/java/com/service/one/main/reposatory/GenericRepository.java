package com.service.one.main.reposatory;

import com.service.one.main.model.GenericModel;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface GenericRepository extends CrudRepository<GenericModel, Long> {
    List<GenericModel> findAll();
}
