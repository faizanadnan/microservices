package com.service.one.main.rest;

import com.service.one.main.model.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/api")
public class RestEndpoint {

    Logger logger = LoggerFactory.getLogger(RestEndpoint.class);

    @Autowired
    private RestTemplate restTemplate;

    @GetMapping("/health")
    public String serviceStatus() {
        logger.debug("Retrieving health information");
        return "up";
    }

    @PostMapping("/greeting")
    public String getGreeting() {
        logger.debug("In Greeting method");
        String greet = restTemplate.getForObject("http://one/greet", String.class);
        User user = new User("Faizan", "Mohammad");
        ResponseEntity<String> userResponseEntity;
        userResponseEntity = restTemplate.postForEntity("http://two/username", user, String.class);
        return greet + " " + userResponseEntity.getBody();
    }

}
