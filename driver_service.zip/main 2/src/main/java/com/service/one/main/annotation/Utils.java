package com.service.one.main.annotation;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Before;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@Configuration
@EnableAspectJAutoProxy
public class Utils {

    @Before("allMethods() && @annotation(LogMethodParam)")
    public static void log( JoinPoint pjp, LogMethodParam logMethodParam) {
                    if ( logMethodParam instanceof LogMethodParam ) {

                        switch ( logMethodParam.logLevel() ) {
                            case INFO:
                            case DEBUG:
                                System.out.println("Method param is"+ pjp.getArgs());
                                break;
            }

        }

    }

}
