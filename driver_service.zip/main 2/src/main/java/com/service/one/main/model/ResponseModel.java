package com.service.one.main.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class ResponseModel {
    @JsonProperty("NAME")
    String name;

    @JsonProperty("SUB_CLASSES")
    List<SubClass> nameVsSubClass;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<SubClass> getNameVsSubClass() {
        return nameVsSubClass;
    }

    public void setNameVsSubClass(List<SubClass> nameVsSubClass) {
        this.nameVsSubClass = nameVsSubClass;
    }
}
