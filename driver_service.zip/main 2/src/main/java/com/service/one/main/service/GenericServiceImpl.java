package com.service.one.main.service;

import com.service.one.main.model.GenericModel;
import com.service.one.main.reposatory.GenericRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GenericServiceImpl implements GenericService {
    @Autowired
    private GenericRepository genericRepository;

    @Override
    public List<GenericModel> getGenericModel() {
        return genericRepository.findAll();
    }
}
