package com.service.one.main.rest;

import com.service.one.main.annotation.LogMethodParam;
import com.service.one.main.model.GenericModel;
import com.service.one.main.model.ResponseModel;
import com.service.one.main.model.SubClass;
import com.service.one.main.service.GenericService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class GenericEndPoints {

    @Autowired
    private GenericService genericService;

    @RequestMapping("/generic/{id}")
    @LogMethodParam
    public ResponseModel getGenericResponse(@PathVariable Long id) {
        List<GenericModel> genericModel = genericService.getGenericModel();
        return buildReposeModel(genericModel, id);
    }

    private ResponseModel buildReposeModel(List<GenericModel> genericModel, Long id) {
        List<SubClass> subClasses = new ArrayList<>();
        ResponseModel responseModel = new ResponseModel();
        genericModel
                .forEach(val->{
                    if (val.getId() == id) {
                        responseModel.setName(val.getName());
                    }
                    if (val.getPatentId() == val.getId()) {
                        subClasses.add(new SubClass(val.getName()));
                    }
                });

        responseModel.setNameVsSubClass(subClasses);
        return responseModel;
    }

}
