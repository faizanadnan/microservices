package com.service.one.main.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SubClass {

    @JsonProperty("name")
    String name;

    public SubClass(String name) {
        this.name = name;
    }

    public SubClass() {
    }
}
