package com.service.one.main.annotation;

public enum Logger {
    INFO,
    DEBUG;
}